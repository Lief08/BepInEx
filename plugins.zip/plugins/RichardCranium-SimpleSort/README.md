> <b>SImple Sort</b>

Lets you sort player and container inventory by name, weight, or value using hotkeys, or automatically on open.

<br/>


>Installation (manual)

- extract `SimpleSort.dll` file to your `BepInEx\Plugins\` folder

<br/>

>About this mod

This mod offers a simple way to sort the player and container inventory, by hovering over the inventory and pressing a customizable key combination of a modifier key and a sort type key.

It also now allows the sort type to stick for either inventory type and get applied each time you open the inventory.

Sort types are:

by <b>name</b> (default key: N)
by <b>weight</b> (default key: H)
by <b>value</b> (default key: V)


<br/>

>Credits

I did not create this mod, all credit goes to aedenthorn. This is a reupload from Nexus Mods with permission given.

> Simple Sort

Lets you sort player and container inventory by name, weight, or value using hotkeys, or automatically on open.

<br/>


> Installation (manual)

- extract `SimpleSort.dll` file to your `BepInEx\Plugins\` folder

<br/>

>About this mod

This mod offers a simple way to sort the player and container inventory, by hovering over the inventory and pressing a customizable key combination of a modifier key and a sort type key.

It also now allows the sort type to stick for either inventory type and get applied each time you open the inventory.

Sort types are:

by <b>name</b> (default key: N)
by <b>weight</b> (default key: H)
by <b>value</b> (default key: V)


<br/>

>Credits

I did not create this mod, all credit goes to aedenthorn. This is a reupload from Nexus Mods with permission given. 

<br/>

>Change Log

Version 0.8.0<br/>
-Fix for 0.217.14


Version 0.7.0<br/>
-Sorting tweaks


Version 0.6.1<br/>
-Fixed not fully combing stacks 


Version 0.6.0<br/>
-Added combining stacks


Version 0.5.0<br/>
-Implemented auto sort


Version 0.4.0<br/>
-Potentially working for gamepads


Version 0.3.1<br/>
-Fixed config label

Version 0.3.0<br/>
-Allow for empty modifier keys


Version 0.2.0<br/>
-Added option to disable player inventory sorting

