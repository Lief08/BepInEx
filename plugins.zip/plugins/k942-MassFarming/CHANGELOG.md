# v1.9.0
* Save plant rotation when using MassFarm

# v1.8.0
* Hildir's Request (0.217.14) compatibility
 
# v1.7.0
* Fix GetRightItem missing method exception patch 0.216.9
* Bump dependency to denikson-BepInExPack_Valheim-5.4.2105

# v1.6.0
* Add options for non-square grids. (migrates configuration from PlantGridSize to PlantGridWidth and PlantGridLength)

# v1.5.0
* Fixed missing method issue due to overload
* Mistlands compatibility
